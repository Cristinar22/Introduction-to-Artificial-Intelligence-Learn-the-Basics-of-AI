# Install required libraries
# Run this in your terminal, not in Python
# pip install tensorflow matplotlib numpy
