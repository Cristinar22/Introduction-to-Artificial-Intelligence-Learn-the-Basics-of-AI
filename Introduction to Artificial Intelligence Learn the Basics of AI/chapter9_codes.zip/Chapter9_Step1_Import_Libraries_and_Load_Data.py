import numpy as np
import pandas as pd
from sklearn.datasets import load_iris

# Load iris data
iris = load_iris()
X = iris.data
y = iris.target

print("Data loaded successfully. X shape:", X.shape, "y shape:", y.shape)
