from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import cross_val_score

# Initialize model
dt = DecisionTreeClassifier(random_state=42)

# Perform 5-fold cross-validation
scores = cross_val_score(dt, X, y, cv=5)

print("Cross-validation scores:", scores)
print("Average accuracy:", scores.mean())
