import numpy as np
import pandas as pd
from sklearn.datasets import load_iris
from sklearn.tree import DecisionTreeClassifier
from sklearn.model_selection import cross_val_score, GridSearchCV, learning_curve
import matplotlib.pyplot as plt

# Load iris data
iris = load_iris()
X = iris.data
y = iris.target
