# Step 2: Extract Data from a Public API
import requests
import pandas as pd

API_KEY = 'your_api_key_here'
city = 'London'
url = f"http://api.openweathermap.org/data/2.5/weather?q={city}&appid={API_KEY}&units=metric"

response = requests.get(url)
data = response.json()

print(data)
