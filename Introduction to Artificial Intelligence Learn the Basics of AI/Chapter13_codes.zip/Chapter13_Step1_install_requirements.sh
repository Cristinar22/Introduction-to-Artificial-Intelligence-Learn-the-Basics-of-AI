#!/bin/bash
# Step 1: Install Required Libraries
pip install requests pandas matplotlib
