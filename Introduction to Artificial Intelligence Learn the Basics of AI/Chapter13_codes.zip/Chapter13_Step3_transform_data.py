# Step 3: Transform Data
import pandas as pd

# Assuming 'data' is retrieved from the API
weather_data = {
    'city': data['name'],
    'temperature': data['main']['temp'],
    'humidity': data['main']['humidity'],
    'pressure': data['main']['pressure'],
    'weather': data['weather'][0]['description']
}

df = pd.DataFrame([weather_data])
print(df)
