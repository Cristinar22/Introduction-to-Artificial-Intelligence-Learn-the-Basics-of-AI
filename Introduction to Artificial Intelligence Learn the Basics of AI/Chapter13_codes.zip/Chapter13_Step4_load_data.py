# Step 4: Load Data into a SQLite Database
import sqlite3
import pandas as pd

# Assuming 'df' is the DataFrame from the transform step
conn = sqlite3.connect('weather_data.db')
df.to_sql('weather', conn, if_exists='append', index=False)

# Verify by reading back
print(pd.read_sql('SELECT * FROM weather', conn))
