# Step 6: Visualize Collected Data
import matplotlib.pyplot as plt
import sqlite3
import pandas as pd

conn = sqlite3.connect('weather_data.db')
df_all = pd.read_sql('SELECT * FROM weather', conn)

plt.bar(df_all['city'], df_all['temperature'])
plt.xlabel('City')
plt.ylabel('Temperature (°C)')
plt.title('Temperature by City')
plt.show()
