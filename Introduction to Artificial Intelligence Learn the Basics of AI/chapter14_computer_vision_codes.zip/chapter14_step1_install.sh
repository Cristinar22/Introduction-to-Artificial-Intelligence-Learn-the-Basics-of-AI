#!/bin/bash
# Chapter 14 Step 1: Install Required Libraries
pip install tensorflow matplotlib numpy
