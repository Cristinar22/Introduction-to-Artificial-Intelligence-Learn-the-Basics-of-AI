# Chapter 14 Step 3: Preprocess Data
# Normalize pixel values to 0–1
train_images = train_images / 255.0
test_images = test_images / 255.0
