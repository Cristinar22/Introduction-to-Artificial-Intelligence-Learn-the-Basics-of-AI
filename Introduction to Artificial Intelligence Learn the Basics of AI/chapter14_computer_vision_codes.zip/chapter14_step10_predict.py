# Chapter 14 Step 10: Predict and Visualize Results
predictions = model.predict(test_images)

def plot_image(i, predictions_array, true_label, img):
    pred_label = np.argmax(predictions_array)
    plt.grid(False)
    plt.xticks([])
    plt.yticks([])
    plt.imshow(img, cmap=plt.cm.binary)
    color = 'blue' if pred_label == true_label else 'red'
    plt.xlabel(f"{class_names[pred_label]} ({100*np.max(predictions_array):.2f}%)", color=color)

plt.figure(figsize=(6,3))
plot_image(0, predictions[0], test_labels[0], test_images[0])
plt.show()
