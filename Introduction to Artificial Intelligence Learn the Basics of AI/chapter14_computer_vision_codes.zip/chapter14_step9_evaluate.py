# Chapter 14 Step 9: Evaluate Model Performance
test_loss, test_acc = model.evaluate(test_images, test_labels)
print(f"Test accuracy: {test_acc:.4f}")
