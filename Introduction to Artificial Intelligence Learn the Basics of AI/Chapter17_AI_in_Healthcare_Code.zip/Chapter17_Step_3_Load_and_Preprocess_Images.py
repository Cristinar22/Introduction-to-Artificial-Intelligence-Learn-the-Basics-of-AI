import os
import cv2
import numpy as np
import matplotlib.pyplot as plt
from tensorflow.keras.utils import to_categorical

def load_images_from_folder(folder, label):
    images = []
    labels = []
    for filename in os.listdir(folder):
        img_path = os.path.join(folder, filename)
        img = cv2.imread(img_path, cv2.IMREAD_GRAYSCALE)
        if img is not None:
            img = cv2.resize(img, (150, 150))
            images.append(img)
            labels.append(label)
    return images, labels

normal_images, normal_labels = load_images_from_folder('chest_xray/train/NORMAL', 0)
pneumonia_images, pneumonia_labels = load_images_from_folder('chest_xray/train/PNEUMONIA', 1)

X = np.array(normal_images + pneumonia_images)
y = np.array(normal_labels + pneumonia_labels)

X = X / 255.0
X = X.reshape(-1, 150, 150, 1)
y = to_categorical(y, num_classes=2)

print(f"Dataset shape: {X.shape}, Labels shape: {y.shape}")
