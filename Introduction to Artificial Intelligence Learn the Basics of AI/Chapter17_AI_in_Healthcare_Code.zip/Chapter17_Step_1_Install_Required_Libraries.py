# No Python code, only pip command
# Run this in your terminal or command line
# pip install tensorflow matplotlib numpy scikit-learn opencv-python
