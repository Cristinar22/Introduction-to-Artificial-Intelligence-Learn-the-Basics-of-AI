import matplotlib.pyplot as plt
import numpy as np

plt.figure(figsize=(10,4))
for i in range(6):
    plt.subplot(2,3,i+1)
    plt.imshow(X[i].reshape(150,150), cmap='gray')
    plt.title('Pneumonia' if np.argmax(y[i]) == 1 else 'Normal')
    plt.axis('off')
plt.show()
