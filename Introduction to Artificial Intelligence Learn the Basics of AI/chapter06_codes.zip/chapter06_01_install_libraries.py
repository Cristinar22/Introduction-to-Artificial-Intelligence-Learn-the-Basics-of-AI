# Step 1: Install Required Libraries
# Run this command in your terminal:
# pip install tensorflow matplotlib numpy
