# Step 7: Train the Model
history = model.fit(X_train, y_train_cat, epochs=10, validation_split=0.2)
