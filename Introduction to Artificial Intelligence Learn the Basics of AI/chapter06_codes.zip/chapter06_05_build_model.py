# Step 5: Build the Neural Network Model
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Flatten

model = Sequential([
    Flatten(input_shape=(28, 28)),      # Flatten 28x28 images into 1D array of 784 pixels
    Dense(128, activation='relu'),      # Hidden layer with 128 neurons and ReLU activation
    Dense(10, activation='softmax')     # Output layer with 10 neurons for digits 0-9
])

model.summary()
