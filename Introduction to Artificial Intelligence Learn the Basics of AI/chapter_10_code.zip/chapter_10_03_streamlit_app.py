import streamlit as st
from tensorflow.keras.models import load_model
from PIL import Image, ImageOps
import numpy as np

# Load model
model = load_model('chapter_10_mnist_model.h5')

st.title("Chapter 10: Handwritten Digit Classifier")

uploaded_file = st.file_uploader("Upload an image of a digit (0-9)", type=["png", "jpg", "jpeg"])

if uploaded_file is not None:
    image = Image.open(uploaded_file).convert('L')
    st.image(image, caption='Uploaded Image', width=150)

    # Preprocess image
    image = ImageOps.invert(image)
    image = image.resize((28,28))
    img_array = np.array(image)/255.0
    img_array = img_array.reshape(1,28,28)

    # Predict
    prediction = model.predict(img_array)
    digit = np.argmax(prediction)
    confidence = np.max(prediction)

    st.write(f"Prediction: {digit} with confidence {confidence:.2f}")
