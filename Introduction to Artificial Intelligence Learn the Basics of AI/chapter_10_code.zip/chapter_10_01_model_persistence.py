import pickle

# Function to save a model
def save_model(model, filename='chapter_10_model.pkl'):
    with open(filename, 'wb') as file:
        pickle.dump(model, file)
    print(f"Model saved to {filename}")

# Function to load a model
def load_model(filename='chapter_10_model.pkl'):
    with open(filename, 'rb') as file:
        model = pickle.load(file)
    print(f"Model loaded from {filename}")
    return model
