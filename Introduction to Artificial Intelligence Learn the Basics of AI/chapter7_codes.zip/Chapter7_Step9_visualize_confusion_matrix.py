import matplotlib.pyplot as plt
from sklearn.metrics import confusion_matrix

# Assuming cm is defined from the evaluation step
# cm = confusion_matrix(y_test, y_pred)

plt.matshow(cm, cmap=plt.cm.Blues)
plt.title('Confusion Matrix')
plt.colorbar()
plt.ylabel('Actual')
plt.xlabel('Predicted')
plt.show()
