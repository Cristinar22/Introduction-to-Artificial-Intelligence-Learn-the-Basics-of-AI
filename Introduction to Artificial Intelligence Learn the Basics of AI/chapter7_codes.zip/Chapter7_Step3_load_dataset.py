import pandas as pd

# Step 3: Load the Movie Reviews Dataset
url = 'https://raw.githubusercontent.com/laxmimerit/twitter-data/master/twitter_sentiment.csv'
data = pd.read_csv(url)

# Show sample data
print(data.head())
print(data['label'].value_counts())
