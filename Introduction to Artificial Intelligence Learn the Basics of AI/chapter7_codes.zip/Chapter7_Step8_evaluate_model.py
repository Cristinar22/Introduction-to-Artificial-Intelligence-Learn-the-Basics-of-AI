from sklearn.metrics import classification_report, confusion_matrix

# Step 8: Make Predictions and Evaluate
y_pred = model.predict(X_test)

print("Classification Report:")
print(classification_report(y_test, y_pred))

cm = confusion_matrix(y_test, y_pred)
print("Confusion Matrix:")
print(cm)
