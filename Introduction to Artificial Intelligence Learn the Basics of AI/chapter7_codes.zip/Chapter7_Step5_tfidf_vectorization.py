from sklearn.feature_extraction.text import TfidfVectorizer

# Step 5: Convert Text to Numerical Features Using TF-IDF
vectorizer = TfidfVectorizer()
X = vectorizer.fit_transform(data['cleaned_text'])
y = data['label'].map({'positive':1, 'negative':0})  # Map labels to 1 and 0
