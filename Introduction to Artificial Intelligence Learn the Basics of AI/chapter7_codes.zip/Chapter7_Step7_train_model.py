from sklearn.linear_model import LogisticRegression

# Step 7: Train the Logistic Regression Model
model = LogisticRegression()
model.fit(X_train, y_train)
