import string
from nltk.corpus import stopwords

def clean_text(text):
    text = text.lower()  # lowercase
    text = ''.join([char for char in text if char not in string.punctuation])  # remove punctuation
    words = text.split()
    words = [word for word in words if word not in stopwords.words('english')]  # remove stop words
    return ' '.join(words)

# Example usage:
# data['cleaned_text'] = data['tweet'].apply(clean_text)
# print(data[['tweet', 'cleaned_text']].head())
