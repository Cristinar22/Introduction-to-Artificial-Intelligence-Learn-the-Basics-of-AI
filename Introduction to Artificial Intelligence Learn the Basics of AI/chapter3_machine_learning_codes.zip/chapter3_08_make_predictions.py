# Step 8: Make Predictions
# Assume model and X_test are defined
y_pred = model.predict(X_test)
print("Predicted prices:", y_pred)
print("Actual prices:", y_test.values)
