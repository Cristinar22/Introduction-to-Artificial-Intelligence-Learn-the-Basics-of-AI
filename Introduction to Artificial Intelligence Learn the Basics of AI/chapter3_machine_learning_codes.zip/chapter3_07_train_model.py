# Step 7: Create and Train the Linear Regression Model
from sklearn.linear_model import LinearRegression

# Assume X_train and y_train are defined
model = LinearRegression()
model.fit(X_train, y_train)
