# Step 5: Prepare the Data for Training
import pandas as pd
import numpy as np

# Sample data
data = pd.DataFrame({
    'Size': np.array([1500, 1800, 2400, 3000, 3500]),
    'Price': np.array([330, 360, 460, 540, 600])
})

X = data[['Size']]  # Features
y = data['Price']   # Labels
