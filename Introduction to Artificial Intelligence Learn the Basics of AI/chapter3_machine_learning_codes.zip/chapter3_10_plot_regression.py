# Step 10: Visualize the Regression Line
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# Sample data
X = np.array([1500, 1800, 2400, 3000, 3500]).reshape(-1, 1)
y = np.array([330, 360, 460, 540, 600])

# Assume model is defined and trained
plt.scatter(X, y)
plt.plot(X, model.predict(X), linewidth=2)
plt.title('Linear Regression Fit')
plt.xlabel('Size (sq ft)')
plt.ylabel('Price ($1000s)')
plt.show()
