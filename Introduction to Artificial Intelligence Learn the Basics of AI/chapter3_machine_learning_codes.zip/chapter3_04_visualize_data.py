# Step 4: Visualize the Data
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

# Sample data
data = pd.DataFrame({
    'Size': np.array([1500, 1800, 2400, 3000, 3500]),
    'Price': np.array([330, 360, 460, 540, 600])
})

plt.scatter(data['Size'], data['Price'])
plt.title('House Size vs Price')
plt.xlabel('Size (sq ft)')
plt.ylabel('Price ($1000s)')
plt.show()
