# Step 6: Split Data into Training and Testing Sets
import pandas as pd
from sklearn.model_selection import train_test_split

# Assume data is already defined
X = pd.DataFrame({'Size': [1500, 1800, 2400, 3000, 3500]})
y = pd.Series([330, 360, 460, 540, 600])

X_train, X_test, y_train, y_test = train_test_split(
    X, y, test_size=0.2, random_state=42
)
