# Step 3: Create a Sample Dataset
import pandas as pd
import numpy as np

house_sizes = np.array([1500, 1800, 2400, 3000, 3500])
house_prices = np.array([330, 360, 460, 540, 600])

data = pd.DataFrame({
    'Size': house_sizes,
    'Price': house_prices
})

print(data)
