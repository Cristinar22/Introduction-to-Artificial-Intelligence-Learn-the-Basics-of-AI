import pandas as pd
import matplotlib.pyplot as plt

# Load Titanic dataset
url = 'https://raw.githubusercontent.com/datasciencedojo/datasets/master/titanic.csv'
data = pd.read_csv(url)

# Fill missing ages with the average age for consistency
data['Age'].fillna(data['Age'].mean(), inplace=True)

# Plot a histogram of ages
plt.hist(data['Age'], bins=20)
plt.title('Age Distribution of Titanic Passengers')
plt.xlabel('Age')
plt.ylabel('Number of Passengers')
plt.show()