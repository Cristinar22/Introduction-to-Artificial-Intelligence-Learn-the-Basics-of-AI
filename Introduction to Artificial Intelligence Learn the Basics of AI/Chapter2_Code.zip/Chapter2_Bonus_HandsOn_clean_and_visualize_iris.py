from sklearn.datasets import load_iris
import pandas as pd
import matplotlib.pyplot as plt

# Load iris data
iris = load_iris()
df = pd.DataFrame(iris.data, columns=iris.feature_names)
df['species'] = iris.target

# Check for missing data
print(df.isnull().sum())

# Plot sepal length distribution
plt.hist(df['sepal length (cm)'], bins=15)
plt.title('Sepal Length Distribution')
plt.xlabel('Sepal Length (cm)')
plt.ylabel('Count')
plt.show()