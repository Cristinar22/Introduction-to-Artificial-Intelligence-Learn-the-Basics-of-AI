import pandas as pd
import matplotlib.pyplot as plt

# Load Titanic dataset
url = 'https://raw.githubusercontent.com/datasciencedojo/datasets/master/titanic.csv'
data = pd.read_csv(url)

# Fill missing ages
data['Age'].fillna(data['Age'].mean(), inplace=True)

# Group data by gender and calculate survival rate
survival_rate = data.groupby('Sex')['Survived'].mean()
print(survival_rate)

# Plot survival rates
survival_rate.plot(kind='bar')
plt.title('Survival Rate by Gender')
plt.ylabel('Survival Rate')
plt.show()