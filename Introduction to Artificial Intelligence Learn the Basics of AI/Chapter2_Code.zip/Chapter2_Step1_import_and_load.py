import pandas as pd
import matplotlib.pyplot as plt

# Load Titanic dataset directly from a URL
url = 'https://raw.githubusercontent.com/datasciencedojo/datasets/master/titanic.csv'
data = pd.read_csv(url)

# Show the first 5 rows of data
print(data.head())