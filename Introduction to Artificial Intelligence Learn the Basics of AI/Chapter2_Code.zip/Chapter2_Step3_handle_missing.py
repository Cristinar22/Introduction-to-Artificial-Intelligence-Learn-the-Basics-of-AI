import pandas as pd

# Load Titanic dataset
url = 'https://raw.githubusercontent.com/datasciencedojo/datasets/master/titanic.csv'
data = pd.read_csv(url)

# Fill missing ages with the average age
average_age = data['Age'].mean()
data['Age'].fillna(average_age, inplace=True)

# Verify that missing ages are filled
print(data['Age'].isnull().sum())