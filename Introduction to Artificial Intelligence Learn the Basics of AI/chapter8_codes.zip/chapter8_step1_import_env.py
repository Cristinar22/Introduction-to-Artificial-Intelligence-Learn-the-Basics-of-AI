import numpy as np
import matplotlib.pyplot as plt

# Define grid size
grid_size = 5

# Define rewards: goal (+10), pit (-10), others (0)
rewards = np.zeros((grid_size, grid_size))
rewards[4, 4] = 10  # Goal at bottom-right corner
rewards[1, 2] = -10  # Pit (bad spot)
rewards[2, 3] = -10  # Another pit
