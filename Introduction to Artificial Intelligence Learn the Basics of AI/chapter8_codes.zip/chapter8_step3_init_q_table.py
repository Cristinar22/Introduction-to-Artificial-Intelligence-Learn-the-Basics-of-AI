# Initialize Q-Table
# The Q-table stores the expected reward for taking each action in each state.
Q = np.zeros((grid_size, grid_size, len(actions)))
