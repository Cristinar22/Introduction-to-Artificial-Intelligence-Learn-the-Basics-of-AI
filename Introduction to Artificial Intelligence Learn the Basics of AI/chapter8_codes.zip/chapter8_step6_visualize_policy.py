# Visualize the Learned Policy
policy = np.chararray((grid_size, grid_size), unicode=True)

for i in range(grid_size):
    for j in range(grid_size):
        best_action_idx = np.argmax(Q[i,j,:])
        policy[i,j] = actions[best_action_idx][0].upper()

print("Learned Policy (U=Up, D=Down, L=Left, R=Right):")
print(policy)
