# Q-Learning Algorithm
for episode in range(num_episodes):
    state = (0, 0)  # Start at top-left corner
    done = False
    for step in range(max_steps_per_episode):
        # Exploration-exploitation trade-off
        if np.random.uniform(0,1) < exploration_rate:
            action_idx = np.random.choice(len(actions))  # Explore
        else:
            action_idx = np.argmax(Q[state[0], state[1], :])  # Exploit

        action = actions[action_idx]
        new_state = get_next_state(state, action)
        reward = rewards[new_state[0], new_state[1]]

        # Update Q-value
        old_value = Q[state[0], state[1], action_idx]
        next_max = np.max(Q[new_state[0], new_state[1], :])
        new_value = old_value + learning_rate * (reward + discount_factor * next_max - old_value)
        Q[state[0], state[1], action_idx] = new_value

        state = new_state

        # Check if goal or pit reached
        if reward == 10 or reward == -10:
            break

    # Decay exploration rate
    exploration_rate = min_exploration_rate + (max_exploration_rate - min_exploration_rate) * np.exp(-exploration_decay_rate*episode)
