# Set Learning Parameters
learning_rate = 0.8
discount_factor = 0.95
exploration_rate = 1.0
max_exploration_rate = 1.0
min_exploration_rate = 0.01
exploration_decay_rate = 0.001
num_episodes = 1000
max_steps_per_episode = 100
