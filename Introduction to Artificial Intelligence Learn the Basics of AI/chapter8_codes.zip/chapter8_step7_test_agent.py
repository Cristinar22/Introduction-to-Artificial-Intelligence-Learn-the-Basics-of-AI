# Test the Agent
state = (0,0)
steps = [state]

while rewards[state[0], state[1]] != 10:
    action_idx = np.argmax(Q[state[0], state[1], :])
    action = actions[action_idx]
    state = get_next_state(state, action)
    steps.append(state)

print("Path taken:", steps)
