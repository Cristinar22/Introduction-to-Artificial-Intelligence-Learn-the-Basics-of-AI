from sklearn.metrics import silhouette_score

# Evaluate clustering performance
score = silhouette_score(X_scaled, labels)
print(f'Silhouette Score: {score:.2f}')
