"""
Chapter 1 - Your First AI Code: Hello AI World!
This script prints a simple greeting to verify setup.
"""

print("Hello AI World!")
