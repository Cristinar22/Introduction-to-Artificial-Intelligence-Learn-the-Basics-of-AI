"""
Chapter 1 - Hands-On Mini Project: Explore Your First Data with Python
This script loads the Iris dataset and displays the first few rows.
"""

import pandas as pd
from sklearn.datasets import load_iris

# Load Iris dataset
iris = load_iris()

# Convert to pandas DataFrame for easier viewing
df = pd.DataFrame(iris.data, columns=iris.feature_names)
df['species'] = iris.target

# Display first few rows
print(df.head())
