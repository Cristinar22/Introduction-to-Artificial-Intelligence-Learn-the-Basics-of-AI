import shap

explainer = shap.TreeExplainer(model)
shap_values = explainer.shap_values(X_test)

# Summary plot for global feature importance
shap.summary_plot(shap_values, X_test, feature_names=X_test.columns)

# Force plot for local explanation of one instance
shap.force_plot(explainer.expected_value[0], shap_values[0][0,:], X_test.iloc[0,:], matplotlib=True)