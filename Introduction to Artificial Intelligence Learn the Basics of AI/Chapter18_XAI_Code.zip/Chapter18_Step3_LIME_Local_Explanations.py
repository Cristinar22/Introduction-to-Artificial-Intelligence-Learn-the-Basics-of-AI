import lime
import lime.lime_tabular

explainer = lime.lime_tabular.LimeTabularExplainer(
    training_data=X_train.values,
    feature_names=X_train.columns,
    class_names=iris.target_names,
    mode='classification'
)

# Choose an instance to explain
i = 1
exp = explainer.explain_instance(X_test.iloc[i].values, model.predict_proba, num_features=4)
exp.show_in_notebook(show_table=True)