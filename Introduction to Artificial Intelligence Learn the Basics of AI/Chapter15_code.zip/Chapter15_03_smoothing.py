import pandas as pd
import matplotlib.pyplot as plt
import yfinance as yf

# Load data
data = yf.download('AAPL', start='2017-01-01', end='2022-01-01')

# Smoothing with Moving Average
data['MA30'] = data['Close'].rolling(window=30).mean()

plt.plot(data['Close'], label='Original')
plt.plot(data['MA30'], label='30-Day Moving Average')
plt.legend()
plt.show()