import matplotlib.pyplot as plt
from sklearn.preprocessing import MinMaxScaler
import numpy as np

# Assume model, X, Y, scaler are available from training step
# Replace these lines with code to load them if stored externally
# model = load_model(...)
# scaler = load_scaler(...)
# X, Y = load_data()

# Predict
train_predict = model.predict(X)
train_predict = scaler.inverse_transform(train_predict)
original_data = scaler.inverse_transform(Y.reshape(-1,1))

plt.plot(original_data, label='Original')
plt.plot(train_predict, label='Predicted')
plt.legend()
plt.show()