import pandas as pd
import matplotlib.pyplot as plt
import yfinance as yf
from statsmodels.tsa.arima.model import ARIMA

# Load data
data = yf.download('AAPL', start='2017-01-01', end='2022-01-01')
close_prices = data['Close'].dropna()

# Fit ARIMA model (p=5, d=1, q=0 as example)
model = ARIMA(close_prices, order=(5,1,0))
model_fit = model.fit()

# Forecast next 30 days
forecast = model_fit.forecast(steps=30)

plt.plot(close_prices, label='Historical')
plt.plot(forecast, label='Forecast')
plt.legend()
plt.show()