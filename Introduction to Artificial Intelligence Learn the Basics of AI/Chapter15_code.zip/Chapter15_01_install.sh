#!/bin/bash
# Chapter 15 Step 1: Install Required Libraries
pip install pandas matplotlib statsmodels numpy scikit-learn tensorflow keras yfinance