import pandas as pd
import matplotlib.pyplot as plt
import yfinance as yf

# Download Apple stock price data
data = yf.download('AAPL', start='2017-01-01', end='2022-01-01')
print(data.head())

# Plot closing price
plt.plot(data['Close'])
plt.title('Apple Stock Closing Prices')
plt.xlabel('Date')
plt.ylabel('Price ($)')
plt.show()