# Step 4: Preprocess Text Data
import pandas as pd
import string
from nltk.corpus import stopwords

def clean_text(text):
    text = text.lower()  # lowercase
    text = ''.join([char for char in text if char not in string.punctuation])  # remove punctuation
    words = text.split()
    words = [word for word in words if word not in stopwords.words('english')]  # remove stop words
    return ' '.join(words)

# Assuming 'data' is already loaded as in step 3
data['Cleaned_Message'] = data['Message'].apply(clean_text)
print(data.head())