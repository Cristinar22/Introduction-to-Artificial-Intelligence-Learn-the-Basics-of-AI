#!/bin/bash
# Step 1: Install Required Libraries
pip install pandas scikit-learn matplotlib nltk