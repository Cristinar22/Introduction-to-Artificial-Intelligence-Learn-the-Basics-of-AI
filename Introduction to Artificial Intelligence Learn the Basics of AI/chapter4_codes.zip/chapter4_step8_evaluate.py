# Step 8: Make Predictions and Evaluate
from sklearn.metrics import confusion_matrix, classification_report
import matplotlib.pyplot as plt

# Assuming model, X_test, and y_test are defined
y_pred = model.predict(X_test)

# Confusion Matrix
cm = confusion_matrix(y_test, y_pred)
print("Confusion Matrix:\n", cm)

# Classification Report (includes precision, recall, F1-score)
print(classification_report(y_test, y_pred))

# Plot confusion matrix
plt.matshow(cm, cmap=plt.cm.Blues)
plt.title('Confusion Matrix')
plt.colorbar()
plt.ylabel('Actual')
plt.xlabel('Predicted')
plt.show()