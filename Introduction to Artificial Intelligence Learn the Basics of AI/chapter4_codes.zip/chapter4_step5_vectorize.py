# Step 5: Convert Text to Numbers
from sklearn.feature_extraction.text import CountVectorizer

# Assuming 'data' has 'Cleaned_Message' column
vectorizer = CountVectorizer()
X = vectorizer.fit_transform(data['Cleaned_Message'])
y = data['Label'].map({'ham':0, 'spam':1})  # Convert labels to 0 and 1