# Step 7: Train the Logistic Regression Model
from sklearn.linear_model import LogisticRegression

# Assuming X_train and y_train are defined
model = LogisticRegression()
model.fit(X_train, y_train)