# Step 3: Load the Dataset
import pandas as pd

# Load dataset from URL
url = "https://raw.githubusercontent.com/justmarkham/pycon-2016-tutorial/master/data/sms.tsv"
data = pd.read_csv(url, sep='\t', header=None, names=['Label', 'Message'])

print(data.head())
print(data['Label'].value_counts())